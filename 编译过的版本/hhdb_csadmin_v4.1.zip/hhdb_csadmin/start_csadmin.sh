export JAVA_HOME=jdk
export CLASSPATH=$JAVA_HOME/lib/tools.jar:$JAVA_HOME/lib/dt.jar
export ANT_HOME=jdk/ant
export PATH=$JAVA_HOME/bin:$ANT_HOME/bin:$PATH
java -jar csadmin.jar
